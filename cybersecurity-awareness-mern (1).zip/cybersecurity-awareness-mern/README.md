# Cybersecurity Awareness Platform (MERN)

A beginner-friendly MERN stack project with learning modules, quiz questions, scoring, quiz history, and admin CRUD.

## Requirements
- Node.js 18+
- MongoDB running locally or a MongoDB Atlas connection string

## Setup

### 1. Backend
```bash
cd server
cp .env.example .env
npm install
npm run seed
npm run dev
```
Edit `server/.env` and set `MONGO_URI` and a long random `JWT_SECRET`.

### 2. Frontend
Open a second terminal:
```bash
cd client
npm install
npm run dev
```
Open the Vite URL shown in the terminal. The React app uses `/api` and Vite proxies it to Express.

## Demo accounts
After running `npm run seed`:
- Admin: `admin@cyberaware.local`
- Password: `ChangeMe123!`

Change this password before using the app beyond a local demo.

## Features
- React dashboard and responsive UI
- Learning module CRUD
- Question CRUD with four options and correct answer
- Quiz with immediate feedback and explanations
- Saved quiz attempts and score history
- JWT authentication and `admin`/`learner` role middleware
- MongoDB models and Express REST API

## Main API routes
- `POST /api/auth/login`
- `GET /api/modules` and admin-only `POST /api/modules`
- `GET /api/modules/:id`, admin-only `PUT/DELETE /api/modules/:id`
- `GET /api/questions`, admin-only `POST /api/questions`
- `PUT/DELETE /api/questions/:id` (admin-only)
- `POST /api/attempts` (signed-in learner)
- `GET /api/attempts/mine` (signed-in learner)
- `GET /api/attempts` (admin-only)
- `GET /api/health`

This is an educational starter project, not a production security certification platform. Add rate limiting, email verification, audit logging, and deployment-specific secret management before production use.
