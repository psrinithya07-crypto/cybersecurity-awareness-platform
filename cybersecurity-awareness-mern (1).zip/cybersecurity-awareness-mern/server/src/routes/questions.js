import { Router } from 'express';
import Question from '../models/Question.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
const router = Router();

router.get('/', async (req, res) => {
  try {
    const filter = req.query.topic ? { topic: new RegExp(String(req.query.topic).slice(0, 80), 'i') } : {};
    const questions = await Question.find(filter).select('-correctAnswer');
    res.json(questions);
  } catch { res.status(500).json({ message: 'Could not load questions.' }); }
});
router.post('/', requireAuth, requireAdmin, async (req, res) => {
  try { res.status(201).json(await Question.create(req.body)); }
  catch (e) { res.status(400).json({ message: e.message || 'Invalid question.' }); }
});
router.put('/:id', requireAuth, requireAdmin, async (req, res) => {
  try {
    const item = await Question.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ message: 'Question not found.' });
    res.json(item);
  } catch (e) { res.status(400).json({ message: e.message || 'Invalid question.' }); }
});
router.delete('/:id', requireAuth, requireAdmin, async (req, res) => {
  try {
    const item = await Question.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: 'Question not found.' });
    res.json({ message: 'Question deleted.' });
  } catch { res.status(400).json({ message: 'Invalid question ID.' }); }
});
export default router;
