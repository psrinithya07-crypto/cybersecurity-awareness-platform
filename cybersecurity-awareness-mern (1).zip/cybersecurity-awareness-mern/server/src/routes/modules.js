import { Router } from 'express';
import Module from '../models/Module.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
const router = Router();

router.get('/', async (_req, res) => {
  try { res.json(await Module.find().sort({ createdAt: -1 })); }
  catch { res.status(500).json({ message: 'Could not load modules.' }); }
});
router.get('/:id', async (req, res) => {
  try {
    const item = await Module.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Module not found.' });
    res.json(item);
  } catch { res.status(400).json({ message: 'Invalid module ID.' }); }
});
router.post('/', requireAuth, requireAdmin, async (req, res) => {
  try { res.status(201).json(await Module.create(req.body)); }
  catch (e) { res.status(400).json({ message: e.message || 'Invalid module.' }); }
});
router.put('/:id', requireAuth, requireAdmin, async (req, res) => {
  try {
    const item = await Module.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ message: 'Module not found.' });
    res.json(item);
  } catch (e) { res.status(400).json({ message: e.message || 'Invalid module.' }); }
});
router.delete('/:id', requireAuth, requireAdmin, async (req, res) => {
  try {
    const item = await Module.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: 'Module not found.' });
    res.json({ message: 'Module deleted.' });
  } catch { res.status(400).json({ message: 'Invalid module ID.' }); }
});
export default router;
