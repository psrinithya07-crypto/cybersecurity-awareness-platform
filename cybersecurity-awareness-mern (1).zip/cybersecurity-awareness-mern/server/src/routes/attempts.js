import { Router } from 'express';
import Attempt from '../models/Attempt.js';
import Question from '../models/Question.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
const router = Router();

router.post('/', requireAuth, async (req, res) => {
  try {
    const answers = Array.isArray(req.body.answers) ? req.body.answers : [];
    if (!answers.length || answers.length > 50) return res.status(400).json({ message: 'Submit between 1 and 50 answers.' });
    const ids = answers.map(a => a.question);
    const questions = await Question.find({ _id: { $in: ids } });
    const byId = new Map(questions.map(q => [String(q._id), q]));
    let score = 0;
    const reviewed = answers.map(a => {
      const q = byId.get(String(a.question));
      if (!q || !Number.isInteger(Number(a.selected)) || Number(a.selected) < 0 || Number(a.selected) > 3) {
        throw new Error('An answer is invalid.');
      }
      const correct = Number(a.selected) === q.correctAnswer;
      if (correct) score++;
      return { question: q._id, selected: Number(a.selected), correct };
    });
    const total = reviewed.length;
    const attempt = await Attempt.create({ user: req.user._id, score, total, percentage: Math.round(score / total * 100), answers: reviewed });
    res.status(201).json({ id: attempt.id, score, total, percentage: attempt.percentage, answers: reviewed });
  } catch (e) { res.status(400).json({ message: e.message || 'Could not save attempt.' }); }
});
router.get('/mine', requireAuth, async (req, res) => {
  try { res.json(await Attempt.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(50).select('-answers')); }
  catch { res.status(500).json({ message: 'Could not load your results.' }); }
});
router.get('/', requireAuth, requireAdmin, async (_req, res) => {
  try { res.json(await Attempt.find().populate('user', 'name email').sort({ createdAt: -1 }).limit(100).select('-answers')); }
  catch { res.status(500).json({ message: 'Could not load attempts.' }); }
});
export default router;
