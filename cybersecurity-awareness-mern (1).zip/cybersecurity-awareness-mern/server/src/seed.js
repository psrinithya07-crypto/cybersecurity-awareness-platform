import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import User from './models/User.js';
import Module from './models/Module.js';
import Question from './models/Question.js';

await mongoose.connect(process.env.MONGO_URI);
const email = 'admin@cyberaware.local';
const passwordHash = await bcrypt.hash('ChangeMe123!', 12);
await User.updateOne({ email }, { $setOnInsert: { name: 'CyberAware Admin', email, passwordHash, role: 'admin' } }, { upsert: true });
const lesson = await Module.findOneAndUpdate(
  { title: 'Password Security' },
  { $setOnInsert: { title: 'Password Security', category: 'Account Safety', level: 'Beginner', durationMinutes: 5, summary: 'Create strong, unique passwords and protect your accounts.', content: 'Use a long passphrase or password manager to create unique passwords for every account. Turn on multi-factor authentication. Never share one-time passwords or recovery codes.' } },
  { upsert: true, new: true, setDefaultsOnInsert: true }
);
const starter = [
  { topic: 'Phishing', question: 'An urgent email asks you to verify your password through a link. What should you do?', options: ['Click immediately', 'Check the sender and visit the official site directly', 'Reply with your password', 'Forward it to everyone'], correctAnswer: 1, explanation: 'Urgency and password requests are common phishing tactics. Verify through the official website.' },
  { topic: 'Passwords', question: 'Which password is the strongest choice?', options: ['password123', 'YourName2026', 'Mango!River!Cloud!47', '123456789'], correctAnswer: 2, explanation: 'A long, unique passphrase is harder to guess.' },
  { topic: 'MFA', question: 'What does multi-factor authentication add?', options: ['A second proof of identity', 'A shorter password', 'Public profile access', 'Automatic email forwarding'], correctAnswer: 0, explanation: 'MFA adds another verification step.' },
  { topic: 'Safe browsing', question: 'A misspelled website asks for bank details. What is safest?', options: ['Enter details quickly', 'Download its tool', 'Leave and open the official address yourself', 'Share the link'], correctAnswer: 2, explanation: 'Lookalike domains can be used for scams.' },
  { topic: 'Device security', question: 'You find an unknown USB drive. What should you do?', options: ['Plug it in', 'Give it to IT without plugging it in', 'Copy files', 'Use it on a shared computer'], correctAnswer: 1, explanation: 'Unknown USB devices may contain malware.' }
];
for (const q of starter) await Question.updateOne({ question: q.question }, { $setOnInsert: { ...q, module: lesson._id } }, { upsert: true });
console.log('Seed complete. Admin: admin@cyberaware.local / ChangeMe123!');
await mongoose.disconnect();
