import mongoose from 'mongoose';
const attemptSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  score: { type: Number, required: true, min: 0 },
  total: { type: Number, required: true, min: 1 },
  percentage: { type: Number, required: true, min: 0, max: 100 },
  answers: [{ question: { type: mongoose.Schema.Types.ObjectId, ref: 'Question' }, selected: Number, correct: Boolean }]
}, { timestamps: true });
export default mongoose.model('Attempt', attemptSchema);
