import mongoose from 'mongoose';
const questionSchema = new mongoose.Schema({
  module: { type: mongoose.Schema.Types.ObjectId, ref: 'Module', default: null },
  topic: { type: String, required: true, trim: true },
  question: { type: String, required: true, trim: true, maxlength: 1000 },
  options: { type: [String], required: true, validate: v => v.length === 4 && v.every(x => x.trim()) },
  correctAnswer: { type: Number, required: true, min: 0, max: 3 },
  explanation: { type: String, default: '', maxlength: 2000 }
}, { timestamps: true });
export default mongoose.model('Question', questionSchema);
