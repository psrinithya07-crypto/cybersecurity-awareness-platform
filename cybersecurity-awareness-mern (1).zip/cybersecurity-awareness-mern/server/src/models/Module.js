import mongoose from 'mongoose';
const moduleSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 120 },
  category: { type: String, required: true, trim: true },
  level: { type: String, enum: ['Beginner', 'Intermediate', 'Advanced'], default: 'Beginner' },
  durationMinutes: { type: Number, min: 1, max: 180, default: 5 },
  summary: { type: String, required: true, maxlength: 300 },
  content: { type: String, required: true, maxlength: 12000 }
}, { timestamps: true });
export default mongoose.model('Module', moduleSchema);
