import React, { useEffect, useState } from 'react';

const api = async (path, options = {}, token = '') => {
  const res = await fetch(path, { ...options, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || 'Request failed');
  return data;
};
const emptyModule = { title: '', category: 'Account Safety', level: 'Beginner', durationMinutes: 5, summary: '', content: '' };
const emptyQuestion = { topic: '', question: '', options: ['', '', '', ''], correctAnswer: 0, explanation: '' };

export default function App() {
  const [modules, setModules] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [attempts, setAttempts] = useState([]);
  const [token, setToken] = useState(localStorage.getItem('cyberaware-token') || '');
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('cyberaware-user') || 'null'));
  const [login, setLogin] = useState({ email: 'admin@cyberaware.local', password: 'ChangeMe123!' });
  const [loginOpen, setLoginOpen] = useState(false);
  const [error, setError] = useState('');
  const [moduleForm, setModuleForm] = useState(emptyModule);
  const [questionForm, setQuestionForm] = useState(emptyQuestion);
  const [quiz, setQuiz] = useState([]);
  const [step, setStep] = useState(-1);
  const [selected, setSelected] = useState({});
  const [review, setReview] = useState(false);
  const [result, setResult] = useState(null);
  const isAdmin = user?.role === 'admin';

  async function refresh() {
    try {
      const [m, q] = await Promise.all([api('/api/modules'), api('/api/questions')]);
      setModules(m); setQuestions(q);
      if (token) {
        const a = await api('/api/attempts/mine', {}, token);
        setAttempts(a);
      } else setAttempts([]);
    } catch (e) { setError(e.message); }
  }
  useEffect(() => { refresh(); }, [token]);

  async function signIn(e) {
    e.preventDefault(); setError('');
    try {
      const data = await api('/api/auth/login', { method: 'POST', body: JSON.stringify(login) });
      setToken(data.token); setUser(data.user);
      localStorage.setItem('cyberaware-token', data.token);
      localStorage.setItem('cyberaware-user', JSON.stringify(data.user));
      setLoginOpen(false);
    } catch (e) { setError(e.message); }
  }
  function signOut() {
    setToken(''); setUser(null); localStorage.removeItem('cyberaware-token'); localStorage.removeItem('cyberaware-user');
  }
  async function saveModule(e) {
    e.preventDefault(); setError('');
    try {
      await api('/api/modules', { method: 'POST', body: JSON.stringify(moduleForm) }, token);
      setModuleForm(emptyModule); await refresh();
    } catch (e) { setError(e.message); }
  }
  async function saveQuestion(e) {
    e.preventDefault(); setError('');
    try {
      await api('/api/questions', { method: 'POST', body: JSON.stringify(questionForm) }, token);
      setQuestionForm(emptyQuestion); await refresh();
    } catch (e) { setError(e.message); }
  }
  async function remove(path) {
    if (!window.confirm('Delete this item?')) return;
    try { await api(path, { method: 'DELETE' }, token); await refresh(); }
    catch (e) { setError(e.message); }
  }
  function startQuiz() {
    const chosen = [...questions].sort(() => Math.random() - .5).slice(0, Math.min(5, questions.length));
    setQuiz(chosen); setSelected({}); setStep(0); setReview(false); setResult(null);
    document.querySelector('#quiz')?.scrollIntoView({ behavior: 'smooth' });
  }
  async function submitQuiz() {
    if (!token) { setError('Sign in to save your quiz result.'); setLoginOpen(true); return; }
    const answers = quiz.map(q => ({ question: q._id, selected: Number(selected[q._id] ?? -1) }));
    if (answers.some(a => a.selected < 0)) { setError('Please answer every question before submitting.'); return; }
    try {
      const data = await api('/api/attempts', { method: 'POST', body: JSON.stringify({ answers }) }, token);
      setResult(data); setReview(true); await refresh();
    } catch (e) { setError(e.message); }
  }
  const publicQuestion = q => q.question;

  return <div className="app">
    <header className="nav"><a className="brand" href="#home"><span className="brand-icon">◈</span> CyberAware</a><nav><a href="#learn">Learning</a><a href="#quiz">Quiz Lab</a><a href="#progress">My Results</a>{isAdmin && <a href="#manage">Manage</a>}</nav><div className="nav-user">{user ? <><span>{user.name}</span><button className="outline-btn" onClick={signOut}>Sign out</button></> : <button className="outline-btn" onClick={() => setLoginOpen(!loginOpen)}>Sign in</button>}</div></header>
    {loginOpen && <form className="login-pop" onSubmit={signIn}><h3>Welcome back</h3><label>Email<input type="email" required value={login.email} onChange={e => setLogin({ ...login, email: e.target.value })} /></label><label>Password<input type="password" required value={login.password} onChange={e => setLogin({ ...login, password: e.target.value })} /></label><button className="btn">Sign in</button><small>Seed demo account is prefilled. Change its password before real use.</small></form>}
    <main>
      <section className="hero" id="home"><div><p className="eyebrow">YOUR DIGITAL SAFETY STARTS HERE</p><h1>Think smart.<br/><span>Stay secure.</span></h1><p className="lead">Build everyday cybersecurity habits with bite-sized lessons and quick quizzes. Learn to spot risks before they become problems.</p><a className="btn" href="#learn">Explore learning ↗</a><a className="hero-link" href="#quiz">Take a quick quiz →</a><p className="micro">✓ Small steps. Safer clicks.</p></div><div className="hero-art"><div className="halo"/><div className="shield">✓</div><div className="float f1">🛡️ <span><b>Protection on</b><small>Good security habits</small></span></div><div className="float f2">✦ <span><b>Knowledge is power</b><small>Learn one thing today</small></span></div></div></section>
      <section className="stats"><div><b>{modules.length}</b><small>Learning modules</small></div><div><b>{questions.length}</b><small>Practice questions</small></div><div><b>{attempts.length}</b><small>Saved quiz attempts</small></div><div><b>5 min</b><small>Average lesson</small></div></section>
      {error && <div className="alert"><span>{error}</span><button onClick={() => setError('')}>×</button></div>}
      <section className="section" id="learn"><p className="eyebrow">LEARN THE ESSENTIALS</p><h2>Security, made simple.</h2><p className="muted">Practical knowledge for your everyday digital life.</p><div className="module-grid">{modules.map((m, i) => <article className="module-card" key={m._id}><div className="module-icon">{['▣','✉','◎','⌁','◇'][i%5]}</div><div className="meta"><span>{m.category}</span><span>{m.level}</span></div><h3>{m.title}</h3><p>{m.summary}</p><details><summary>Read lesson · {m.durationMinutes} min</summary><p className="lesson-content">{m.content}</p></details></article>)}</div>{!modules.length && <p className="muted">Run the seed command to load starter lessons.</p>}</section>
      <section className="quiz-section" id="quiz"><div><p className="eyebrow">PUT YOUR KNOWLEDGE TO THE TEST</p><h2>Ready for a<br/>security check?</h2><p className="muted">Answer questions, see your score, and learn from every answer.</p><ul><li>Instant feedback</li><li>Helpful explanations</li><li>Save results to your account</li></ul><button className="btn" onClick={startQuiz} disabled={!questions.length}>Start quiz →</button></div><div className="quiz-panel"><div className="panel-head"><b>QUIZ LAB</b><span>{step < 0 ? 'Ready when you are' : result ? 'Quiz completed' : `Question ${step+1} of ${quiz.length}`}</span></div>{step < 0 ? <div className="welcome"><div className="qmark">?</div><h3>Test your cyber sense</h3><p>Explore phishing, passwords, safe browsing, and more.</p><button className="btn" onClick={startQuiz} disabled={!questions.length}>Start quiz →</button></div> : result ? <div className="welcome"><div className="qmark">✓</div><h3>{result.percentage >= 70 ? 'Nice work!' : 'Keep practising!'}</h3><p>You scored <b>{result.score} out of {result.total}</b> ({result.percentage}%).</p><button className="btn" onClick={startQuiz}>Try again →</button></div> : <div className="quiz-body"><p className="qtopic">{quiz[step]?.topic}</p><h3>{publicQuestion(quiz[step])}</h3>{quiz[step]?.options.map((o, i) => <label className="option" key={i}><input type="radio" name={`q-${quiz[step]._id}`} checked={Number(selected[quiz[step]._id]) === i} onChange={() => setSelected({ ...selected, [quiz[step]._id]: i })}/><span>{String.fromCharCode(65+i)}. {o}</span></label>)}<div className="quiz-controls">{step > 0 && <button className="outline-btn" onClick={() => setStep(step-1)}>Back</button>}{step < quiz.length-1 ? <button className="btn" onClick={() => { if (selected[quiz[step]._id] === undefined) return setError('Choose an answer first.'); setStep(step+1); }}>Next →</button> : <button className="btn" onClick={submitQuiz}>Submit quiz</button>}</div><small>Your score is calculated by the server.</small></div>}</div></section>
      <section className="section" id="progress"><p className="eyebrow">YOUR LEARNING JOURNEY</p><h2>Progress that matters.</h2><p className="muted">Your saved quiz attempts and scores.</p><div className="white-panel"><h3>Recent attempts</h3>{attempts.length ? attempts.map(a => <div className="result-row" key={a._id}><div><b>Cybersecurity quiz</b><small>{new Date(a.createdAt).toLocaleDateString()}</small></div><div className="bar"><span style={{width:`${a.percentage}%`}}/></div><b>{a.score}/{a.total} · {a.percentage}%</b></div>) : <p className="muted">Sign in and take a quiz to save results here.</p>}</div></section>
      {isAdmin && <section className="section manage" id="manage"><p className="eyebrow">ADMIN CONTENT WORKSPACE</p><h2>Manage learning content.</h2><p className="muted">Only administrator accounts can add, update, or remove content.</p><div className="manage-grid"><form className="white-panel" onSubmit={saveModule}><h3>Add a learning module</h3><label>Title<input required value={moduleForm.title} onChange={e=>setModuleForm({...moduleForm,title:e.target.value})}/></label><div className="form-row"><label>Category<input required value={moduleForm.category} onChange={e=>setModuleForm({...moduleForm,category:e.target.value})}/></label><label>Level<select value={moduleForm.level} onChange={e=>setModuleForm({...moduleForm,level:e.target.value})}><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select></label></div><label>Duration in minutes<input type="number" min="1" max="180" value={moduleForm.durationMinutes} onChange={e=>setModuleForm({...moduleForm,durationMinutes:Number(e.target.value)})}/></label><label>Summary<input required value={moduleForm.summary} onChange={e=>setModuleForm({...moduleForm,summary:e.target.value})}/></label><label>Lesson content<textarea required rows="4" value={moduleForm.content} onChange={e=>setModuleForm({...moduleForm,content:e.target.value})}/></label><button className="btn">Add module</button></form><form className="white-panel" onSubmit={saveQuestion}><h3>Add a quiz question</h3><label>Topic<input required value={questionForm.topic} onChange={e=>setQuestionForm({...questionForm,topic:e.target.value})}/></label><label>Question<textarea required value={questionForm.question} onChange={e=>setQuestionForm({...questionForm,question:e.target.value})}/></label>{questionForm.options.map((o,i)=><label key={i}>Option {String.fromCharCode(65+i)}<input required value={o} onChange={e=>setQuestionForm({...questionForm,options:questionForm.options.map((x,j)=>i===j?e.target.value:x)})}/></label>)}<label>Correct answer<select value={questionForm.correctAnswer} onChange={e=>setQuestionForm({...questionForm,correctAnswer:Number(e.target.value)})}>{questionForm.options.map((_,i)=><option value={i} key={i}>Option {String.fromCharCode(65+i)}</option>)}</select></label><label>Explanation<textarea rows="2" value={questionForm.explanation} onChange={e=>setQuestionForm({...questionForm,explanation:e.target.value})}/></label><button className="btn">Add question</button></form></div><div className="white-panel admin"><h3>Existing modules</h3>{modules.map(m=><div className="admin-row" key={m._id}><span>{m.title}</span><button className="delete-btn" onClick={()=>remove('/api/modules/'+m._id)}>Delete</button></div>)}<h3>Existing questions</h3>{questions.map(q=><div className="admin-row" key={q._id}><span>{q.topic}: {q.question}</span><button className="delete-btn" onClick={()=>remove('/api/questions/'+q._id)}>Delete</button></div>)}</div></section>}
    </main><footer><b>◈ CyberAware</b><span>Learn safely. Click thoughtfully. Protect what matters.</span></footer>
  </div>;
}
